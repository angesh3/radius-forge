#!/bin/bash
echo "==========================================="
echo "RadiusForge Delta Update to v1.3.1"
echo "==========================================="

INSTALL_DIR="/opt/radiusforge"

# Detect if running with sudo
if [[ $EUID -ne 0 ]]; then
    SUDO="sudo"
else
    SUDO=""
fi

# Backup current version
echo "Creating backup..."
$SUDO cp -r $INSTALL_DIR ${INSTALL_DIR}.backup.$(date +%Y%m%d_%H%M%S)

# Apply updates
echo "Applying updates..."
$SUDO cp -r scripts/* $INSTALL_DIR/scripts/
$SUDO cp -r src/* $INSTALL_DIR/src/
$SUDO cp -r ui-build/* $INSTALL_DIR/ui-build/ 2>/dev/null || true
$SUDO cp -r config/* $INSTALL_DIR/config/
$SUDO cp VERSION $INSTALL_DIR/
$SUDO cp manifest.json $INSTALL_DIR/

# Set permissions
$SUDO chmod +x $INSTALL_DIR/scripts/startup/*.sh
$SUDO chmod +x $INSTALL_DIR/scripts/*.sh

# Restart service
echo "Restarting service..."
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    $SUDO systemctl restart radiusforge 2>/dev/null || \
    $SUDO $INSTALL_DIR/scripts/startup/radiusforge-rhel.sh restart
elif [[ "$OSTYPE" == "darwin"* ]]; then
    $INSTALL_DIR/scripts/startup/radiusforge-macos.sh restart
fi

echo ""
echo "Update complete to v1.3.1!"
echo "New features:"
echo "  • Enhanced startup scripts for macOS and RHEL"
echo "  • Improved service management"
echo "  • Health monitoring service"
echo "  • Better cross-platform support"
echo ""
echo "Port range: 8910-8920"
