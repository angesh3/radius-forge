#!/bin/bash
echo "==========================================="
echo "RadiusForge Delta Update to v1.3.0"
echo "==========================================="

INSTALL_DIR="/opt/radiusforge"

# Backup current version
echo "Creating backup..."
sudo cp -r $INSTALL_DIR ${INSTALL_DIR}.backup.$(date +%Y%m%d_%H%M%S)

# Apply updates
echo "Applying updates..."
sudo cp -r src/* $INSTALL_DIR/src/
sudo cp -r ui-build/* $INSTALL_DIR/ui-build/
sudo cp VERSION $INSTALL_DIR/
sudo cp port-config.json $INSTALL_DIR/
sudo cp manifest.json $INSTALL_DIR/

# Restart service
echo "Restarting service..."
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    sudo systemctl restart radiusforge
elif [[ "$OSTYPE" == "darwin"* ]]; then
    sudo launchctl stop com.radiusforge
    sudo launchctl start com.radiusforge
fi

echo "Update complete to v1.3.0!"
echo "New port range: 8910-8920"
