#!/usr/bin/env python3
"""
RadiusForge WebSocket Manager
Handles WebSocket connections for real-time updates
"""

from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List, Set, Any, Optional
import json
import asyncio
import logging
from datetime import datetime
from contextlib import asynccontextmanager
import uuid

from .config import settings

logger = logging.getLogger(__name__)


class WebSocketConnection:
    """Represents a single WebSocket connection with metadata"""
    
    def __init__(self, websocket: WebSocket, client_id: str = None):
        self.websocket = websocket
        self.client_id = client_id or str(uuid.uuid4())
        self.connected_at = datetime.utcnow()
        self.subscriptions: Set[str] = set()
        self.metadata: Dict[str, Any] = {}
        self.last_ping = datetime.utcnow()
    
    async def send_json(self, data: Dict[str, Any]):
        """Send JSON data to this connection"""
        try:
            await self.websocket.send_json(data)
        except Exception as e:
            logger.error(f"Failed to send data to client {self.client_id}: {e}")
            raise
    
    async def send_text(self, text: str):
        """Send text data to this connection"""
        try:
            await self.websocket.send_text(text)
        except Exception as e:
            logger.error(f"Failed to send text to client {self.client_id}: {e}")
            raise
    
    def subscribe(self, topic: str):
        """Subscribe to a topic"""
        self.subscriptions.add(topic)
    
    def unsubscribe(self, topic: str):
        """Unsubscribe from a topic"""
        self.subscriptions.discard(topic)
    
    def is_subscribed(self, topic: str) -> bool:
        """Check if subscribed to a topic"""
        return topic in self.subscriptions
    
    def update_ping(self):
        """Update last ping timestamp"""
        self.last_ping = datetime.utcnow()


class WebSocketManager:
    """Manages WebSocket connections and broadcasting"""
    
    def __init__(self):
        self.connections: Dict[str, WebSocketConnection] = {}
        self.topic_subscribers: Dict[str, Set[str]] = {}
        self._lock = asyncio.Lock()
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._start_heartbeat()
    
    def _start_heartbeat(self):
        """Start the heartbeat task"""
        if self._heartbeat_task is None or self._heartbeat_task.done():
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
    
    async def _heartbeat_loop(self):
        """Heartbeat loop to check connection health"""
        while True:
            try:
                await asyncio.sleep(settings.WS_HEARTBEAT_INTERVAL)
                await self._check_connections()
            except Exception as e:
                logger.error(f"Heartbeat loop error: {e}")
    
    async def _check_connections(self):
        """Check and clean up stale connections"""
        async with self._lock:
            stale_clients = []
            current_time = datetime.utcnow()
            
            for client_id, conn in self.connections.items():
                # Check if connection is stale (no ping for 2x heartbeat interval)
                time_since_ping = (current_time - conn.last_ping).total_seconds()
                if time_since_ping > (settings.WS_HEARTBEAT_INTERVAL * 2):
                    stale_clients.append(client_id)
            
            # Remove stale connections
            for client_id in stale_clients:
                await self._remove_connection(client_id)
                logger.info(f"Removed stale connection: {client_id}")
    
    async def connect(self, websocket: WebSocket, client_id: str = None) -> str:
        """Accept a new WebSocket connection"""
        try:
            await websocket.accept()
            
            # Check connection limit
            if len(self.connections) >= settings.WS_MAX_CONNECTIONS:
                await websocket.send_json({
                    "type": "error",
                    "message": "Maximum connections reached"
                })
                await websocket.close()
                raise Exception("Maximum connections reached")
            
            # Create connection
            connection = WebSocketConnection(websocket, client_id)
            
            async with self._lock:
                self.connections[connection.client_id] = connection
            
            logger.info(f"WebSocket connected: {connection.client_id}")
            return connection.client_id
            
        except Exception as e:
            logger.error(f"Failed to connect WebSocket: {e}")
            raise
    
    async def disconnect(self, websocket: WebSocket):
        """Disconnect a WebSocket connection"""
        async with self._lock:
            # Find connection by websocket
            client_id = None
            for cid, conn in self.connections.items():
                if conn.websocket == websocket:
                    client_id = cid
                    break
            
            if client_id:
                await self._remove_connection(client_id)
    
    async def disconnect_client(self, client_id: str):
        """Disconnect a specific client"""
        async with self._lock:
            await self._remove_connection(client_id)
    
    async def _remove_connection(self, client_id: str):
        """Remove a connection (internal method)"""
        if client_id in self.connections:
            connection = self.connections[client_id]
            
            # Remove from topic subscriptions
            for topic in connection.subscriptions:
                if topic in self.topic_subscribers:
                    self.topic_subscribers[topic].discard(client_id)
                    if not self.topic_subscribers[topic]:
                        del self.topic_subscribers[topic]
            
            # Remove connection
            del self.connections[client_id]
            logger.info(f"WebSocket disconnected: {client_id}")
    
    async def disconnect_all(self):
        """Disconnect all WebSocket connections"""
        async with self._lock:
            for client_id in list(self.connections.keys()):
                await self._remove_connection(client_id)
        
        # Cancel heartbeat task
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
    
    async def send_to_client(self, client_id: str, data: Dict[str, Any]):
        """Send data to a specific client"""
        connection = self.connections.get(client_id)
        if connection:
            try:
                await connection.send_json(data)
            except Exception as e:
                logger.error(f"Failed to send to client {client_id}: {e}")
                await self.disconnect_client(client_id)
    
    async def broadcast(self, data: Dict[str, Any], topic: str = None):
        """Broadcast data to all connections or topic subscribers"""
        if not self.connections:
            return
        
        async with self._lock:
            clients_to_send = []
            
            if topic:
                # Send to topic subscribers only
                if topic in self.topic_subscribers:
                    clients_to_send = list(self.topic_subscribers[topic])
            else:
                # Send to all connections
                clients_to_send = list(self.connections.keys())
        
        # Send to clients (outside of lock to avoid blocking)
        failed_clients = []
        for client_id in clients_to_send:
            try:
                await self.send_to_client(client_id, data)
            except Exception:
                failed_clients.append(client_id)
        
        # Remove failed clients
        for client_id in failed_clients:
            await self.disconnect_client(client_id)
    
    async def subscribe(self, websocket: WebSocket, topics: List[str]):
        """Subscribe a connection to topics"""
        # Find connection
        connection = None
        for conn in self.connections.values():
            if conn.websocket == websocket:
                connection = conn
                break
        
        if not connection:
            return
        
        async with self._lock:
            for topic in topics:
                connection.subscribe(topic)
                
                # Add to topic subscribers
                if topic not in self.topic_subscribers:
                    self.topic_subscribers[topic] = set()
                self.topic_subscribers[topic].add(connection.client_id)
        
        logger.info(f"Client {connection.client_id} subscribed to topics: {topics}")
    
    async def unsubscribe(self, websocket: WebSocket, topics: List[str]):
        """Unsubscribe a connection from topics"""
        # Find connection
        connection = None
        for conn in self.connections.values():
            if conn.websocket == websocket:
                connection = conn
                break
        
        if not connection:
            return
        
        async with self._lock:
            for topic in topics:
                connection.unsubscribe(topic)
                
                # Remove from topic subscribers
                if topic in self.topic_subscribers:
                    self.topic_subscribers[topic].discard(connection.client_id)
                    if not self.topic_subscribers[topic]:
                        del self.topic_subscribers[topic]
        
        logger.info(f"Client {connection.client_id} unsubscribed from topics: {topics}")
    
    async def ping_client(self, client_id: str):
        """Send ping to a specific client"""
        await self.send_to_client(client_id, {"type": "ping"})
    
    async def handle_pong(self, websocket: WebSocket):
        """Handle pong response from client"""
        # Find connection and update ping time
        for conn in self.connections.values():
            if conn.websocket == websocket:
                conn.update_ping()
                break
    
    def get_connection_count(self) -> int:
        """Get total number of connections"""
        return len(self.connections)
    
    def get_topic_subscriber_count(self, topic: str) -> int:
        """Get number of subscribers for a topic"""
        return len(self.topic_subscribers.get(topic, set()))
    
    def get_stats(self) -> Dict[str, Any]:
        """Get WebSocket manager statistics"""
        return {
            "total_connections": len(self.connections),
            "topics": {
                topic: len(subscribers) 
                for topic, subscribers in self.topic_subscribers.items()
            },
            "heartbeat_interval": settings.WS_HEARTBEAT_INTERVAL,
            "max_connections": settings.WS_MAX_CONNECTIONS
        }