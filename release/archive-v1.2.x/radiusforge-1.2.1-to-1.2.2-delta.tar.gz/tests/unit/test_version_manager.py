"""Unit tests for Version Manager"""

import pytest
import json
from pathlib import Path
import tempfile
import shutil
from unittest.mock import Mock, patch, MagicMock

# Import after adding to path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from ops.version_manager import VersionManager


class TestVersionManager:
    """Test suite for VersionManager"""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for testing"""
        temp_dir = tempfile.mkdtemp()
        yield Path(temp_dir)
        shutil.rmtree(temp_dir)
    
    @pytest.fixture
    def version_manager(self, temp_dir):
        """Create VersionManager instance with temp directory"""
        return VersionManager(base_dir=temp_dir)
    
    def test_get_current_version_default(self, version_manager):
        """Test getting default version when VERSION file doesn't exist"""
        assert version_manager.get_current_version() == "1.0.0"
    
    def test_get_current_version_from_file(self, version_manager):
        """Test reading version from VERSION file"""
        version_manager.version_file.write_text("2.3.4")
        assert version_manager.get_current_version() == "2.3.4"
    
    def test_bump_version_patch(self, version_manager):
        """Test patch version bump"""
        version_manager.version_file.write_text("1.2.3")
        new_version = version_manager.bump_version("patch")
        assert new_version == "1.2.4"
        assert version_manager.get_current_version() == "1.2.4"
    
    def test_bump_version_minor(self, version_manager):
        """Test minor version bump"""
        version_manager.version_file.write_text("1.2.3")
        new_version = version_manager.bump_version("minor")
        assert new_version == "1.3.0"
        assert version_manager.get_current_version() == "1.3.0"
    
    def test_bump_version_major(self, version_manager):
        """Test major version bump"""
        version_manager.version_file.write_text("1.2.3")
        new_version = version_manager.bump_version("major")
        assert new_version == "2.0.0"
        assert version_manager.get_current_version() == "2.0.0"
    
    def test_create_manifest(self, version_manager):
        """Test manifest creation"""
        manifest = version_manager.create_manifest("1.2.3", "full")
        
        assert manifest["version"] == "1.2.3"
        assert manifest["bundle_type"] == "full"
        assert "created_at" in manifest
        assert "ports" in manifest
        assert manifest["ports"]["api"] == 8910
        assert manifest["ports"]["ui"] == 8911
        assert manifest["ports"]["syslog"] == 8915
    
    def test_calculate_file_hash(self, version_manager, temp_dir):
        """Test file hash calculation"""
        test_file = temp_dir / "test.txt"
        test_file.write_text("Hello, World!")
        
        hash_value = version_manager.calculate_file_hash(test_file)
        # SHA256 of "Hello, World!"
        expected_hash = "dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f"
        assert hash_value == expected_hash
    
    def test_get_project_files(self, version_manager, temp_dir):
        """Test getting project files with exclusions"""
        # Create test files
        (temp_dir / "app.py").write_text("print('app')")
        (temp_dir / "test.pyc").write_text("compiled")
        (temp_dir / "__pycache__").mkdir()
        (temp_dir / "__pycache__" / "cache.py").write_text("cache")
        (temp_dir / ".git").mkdir()
        (temp_dir / ".git" / "config").write_text("git config")
        
        files = version_manager.get_project_files()
        file_names = [str(f) for f in files]
        
        assert "app.py" in file_names
        assert "test.pyc" not in file_names
        assert "__pycache__/cache.py" not in file_names
        assert ".git/config" not in file_names
    
    def test_get_changed_files_no_old_manifest(self, version_manager):
        """Test getting changed files when no old manifest exists"""
        with patch.object(version_manager, 'get_project_files') as mock_files:
            mock_files.return_value = [Path("file1.py"), Path("file2.py")]
            
            changed = version_manager.get_changed_files("1.0.0", "1.1.0")
            assert changed == [Path("file1.py"), Path("file2.py")]
    
    def test_update_version_history(self, version_manager, temp_dir):
        """Test updating version history"""
        bundle_path = temp_dir / "bundle.tar.gz"
        bundle_path.write_text("bundle content")
        
        version_manager.update_version_history("1.2.3", "full", bundle_path)
        
        assert version_manager.history_file.exists()
        with open(version_manager.history_file) as f:
            history = json.load(f)
        
        assert len(history) == 1
        assert history[0]["version"] == "1.2.3"
        assert history[0]["bundle_type"] == "full"
        assert history[0]["bundle_path"] == "bundle.tar.gz"
    
    @patch('subprocess.run')
    def test_get_git_commit(self, mock_run, version_manager):
        """Test getting git commit hash"""
        mock_run.return_value = MagicMock(
            stdout="abc123def456789",
            returncode=0
        )
        
        commit = version_manager._get_git_commit()
        assert commit == "abc123de"  # First 8 characters
    
    def test_port_configuration(self, version_manager):
        """Test that port configuration uses new 8910-8920 range"""
        manifest = version_manager.create_manifest("1.0.0", "full")
        
        ports = manifest["ports"]
        assert ports["api"] == 8910
        assert ports["ui"] == 8911
        assert ports["websocket"] == 8912
        assert ports["syslog"] == 8915
        assert ports["metrics"] == 8919
        
        # Verify all ports are in the correct range
        for port_name, port_value in ports.items():
            assert 8910 <= port_value <= 8920, f"Port {port_name}={port_value} outside range 8910-8920"