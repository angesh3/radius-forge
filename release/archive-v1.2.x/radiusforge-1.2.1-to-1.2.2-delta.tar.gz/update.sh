#!/bin/bash
# RadiusForge Delta Update Script
# Updates from 1.2.1 to 1.2.2

set -e

echo "Starting RadiusForge update from 1.2.1 to 1.2.2..."

# Backup current version
if [ -d "backup" ]; then
    rm -rf backup.old
    mv backup backup.old
fi
mkdir -p backup
cp -r . backup/ 2>/dev/null || true

# Apply updates
echo "Applying delta updates..."
tar -xzf radiusforge-1.2.1-to-1.2.2-delta.tar.gz

# Update VERSION file
echo "1.2.2" > VERSION

# Restart services
echo "Restarting services..."
if command -v systemctl &> /dev/null; then
    systemctl restart radiusforge-api || true
    systemctl restart radiusforge-ui || true
else
    pkill -f "uvicorn" || true
    pkill -f "npm" || true
fi

echo "Update complete! RadiusForge is now at version 1.2.2"
