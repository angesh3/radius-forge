import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Layout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const location = useLocation();

  const navigationItems = [
    {
      path: '/scale-test',
      name: 'Scale Test',
      icon: '📈',
      description: 'RPS Planner & Load Testing'
    },
    {
      path: '/performance-test',
      name: 'Performance Test',
      icon: '⚡',
      description: 'SLO Benchmark Suite'
    },
    {
      path: '/threat-generator',
      name: 'Threat Generator',
      icon: '⚠️',
      description: 'Adversarial Traffic Modules'
    },
    {
      path: '/report',
      name: 'Report',
      icon: '📊',
      description: 'Generate & Distribute Reports'
    },
    {
      path: '/topology',
      name: 'Topology',
      icon: '🌐',
      description: 'Network Visualization'
    },
    {
      path: '/history',
      name: 'History & Compare',
      icon: '📜',
      description: 'Run Catalog & Comparisons'
    },
    {
      path: '/help',
      name: 'Help',
      icon: '❓',
      description: 'Documentation & Guides'
    }
  ];

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const isActive = (path) => {
    return location.pathname === path || (path === '/scale-test' && location.pathname === '/');
  };

  return (
    <div className="layout">
      <div className="header">
        <div className="header-left">
          <button className="sidebar-toggle" onClick={toggleSidebar}>
            {isSidebarOpen ? '←' : '→'}
          </button>
          <div className="logo">
            <span className="logo-icon">🔥</span>
            <span className="logo-text">RadiusForge</span>
          </div>
        </div>
        <div className="header-right">
          <div className="status-indicator">
            <span className="status-dot healthy"></span>
            <span className="status-text">System Healthy</span>
          </div>
          <div className="user-menu">
            <span className="user-icon">👤</span>
            <span className="user-name">Admin</span>
          </div>
        </div>
      </div>

      <div className="main-container">
        <nav className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`}>
          <div className="nav-section">
            <div className="nav-title">Testing Tools</div>
            {navigationItems.slice(0, 3).map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-item ${isActive(item.path) ? 'active' : ''}`}
              >
                <span className="nav-icon">{item.icon}</span>
                {isSidebarOpen && (
                  <div className="nav-content">
                    <span className="nav-name">{item.name}</span>
                    <span className="nav-description">{item.description}</span>
                  </div>
                )}
              </Link>
            ))}
          </div>

          <div className="nav-section">
            <div className="nav-title">Analysis & Reports</div>
            {navigationItems.slice(3, 6).map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-item ${isActive(item.path) ? 'active' : ''}`}
              >
                <span className="nav-icon">{item.icon}</span>
                {isSidebarOpen && (
                  <div className="nav-content">
                    <span className="nav-name">{item.name}</span>
                    <span className="nav-description">{item.description}</span>
                  </div>
                )}
              </Link>
            ))}
          </div>

          <div className="nav-section">
            <div className="nav-title">Support</div>
            {navigationItems.slice(6).map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-item ${isActive(item.path) ? 'active' : ''}`}
              >
                <span className="nav-icon">{item.icon}</span>
                {isSidebarOpen && (
                  <div className="nav-content">
                    <span className="nav-name">{item.name}</span>
                    <span className="nav-description">{item.description}</span>
                  </div>
                )}
              </Link>
            ))}
          </div>
        </nav>

        <main className="content">
          {children}
        </main>
      </div>

      <style jsx>{`
        .layout {
          display: flex;
          flex-direction: column;
          height: 100vh;
          background-color: #f5f5f5;
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: white;
          padding: 12px 20px;
          border-bottom: 1px solid #e0e0e0;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          z-index: 1000;
        }

        .header-left {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .sidebar-toggle {
          background: none;
          border: 1px solid #ddd;
          border-radius: 4px;
          padding: 8px 12px;
          cursor: pointer;
          font-size: 14px;
          color: #666;
          transition: all 0.2s;
        }

        .sidebar-toggle:hover {
          background-color: #f8f9fa;
          border-color: #999;
        }

        .logo {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .logo-icon {
          font-size: 24px;
        }

        .logo-text {
          font-size: 20px;
          font-weight: 700;
          color: #333;
        }

        .header-right {
          display: flex;
          align-items: center;
          gap: 20px;
        }

        .status-indicator {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
        }

        .status-dot.healthy {
          background-color: #28a745;
        }

        .status-text {
          font-size: 14px;
          color: #666;
        }

        .user-menu {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 12px;
          border-radius: 6px;
          background-color: #f8f9fa;
        }

        .user-icon {
          font-size: 16px;
        }

        .user-name {
          font-size: 14px;
          color: #333;
          font-weight: 500;
        }

        .main-container {
          display: flex;
          flex: 1;
          overflow: hidden;
        }

        .sidebar {
          background: white;
          border-right: 1px solid #e0e0e0;
          transition: all 0.3s ease;
          overflow-y: auto;
          z-index: 100;
        }

        .sidebar.open {
          width: 280px;
        }

        .sidebar.closed {
          width: 60px;
        }

        .nav-section {
          padding: 20px 0;
          border-bottom: 1px solid #f0f0f0;
        }

        .nav-section:last-child {
          border-bottom: none;
        }

        .nav-title {
          padding: 0 20px 12px 20px;
          font-size: 12px;
          font-weight: 600;
          text-transform: uppercase;
          color: #999;
          letter-spacing: 0.5px;
        }

        .sidebar.closed .nav-title {
          display: none;
        }

        .nav-item {
          display: flex;
          align-items: center;
          gap: 15px;
          padding: 12px 20px;
          text-decoration: none;
          color: #666;
          transition: all 0.2s;
          border-left: 3px solid transparent;
        }

        .nav-item:hover {
          background-color: #f8f9fa;
          color: #333;
        }

        .nav-item.active {
          background-color: #007bff;
          color: white;
          border-left-color: #0056b3;
        }

        .nav-icon {
          font-size: 18px;
          min-width: 18px;
          text-align: center;
        }

        .nav-content {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .nav-name {
          font-weight: 500;
          font-size: 14px;
        }

        .nav-description {
          font-size: 12px;
          opacity: 0.8;
        }

        .sidebar.closed .nav-content {
          display: none;
        }

        .content {
          flex: 1;
          overflow-y: auto;
          background-color: #f5f5f5;
        }

        @media (max-width: 768px) {
          .sidebar.open {
            position: fixed;
            left: 0;
            top: 60px;
            height: calc(100vh - 60px);
            width: 280px;
            z-index: 999;
          }

          .sidebar.closed {
            transform: translateX(-100%);
          }

          .content {
            margin-left: 0;
          }

          .header {
            padding: 8px 15px;
          }

          .logo-text {
            display: none;
          }

          .status-indicator {
            display: none;
          }
        }
      `}</style>
    </div>
  );
};

export default Layout;