import { useState, useEffect } from 'react';

const ScaleTest = () => {
  const [target, setTarget] = useState({
    host: '',
    port: '1812',
    secret: '',
    type: 'Asset Manager'
  });
  
  const [trafficConfig, setTrafficConfig] = useState({
    type: 'RADIUS',
    authType: 'PAP',
    rpsProfile: 'Constant',
    rpsValue: 150,
    duration: '00:60',
    clients: 10,
    accounting: true,
    rejectRate: 0
  });

  const [liveKpis, setLiveKpis] = useState({
    currentRps: 0,
    targetRps: 0,
    deliveredPercent: 0,
    tps: 0,
    activeSockets: 0,
    latencyP50: 0,
    latencyP95: 0,
    latencyP99: 0,
    successRate: 0,
    errorRate: 0,
    timeouts: 0,
    coaLatency: 0
  });

  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const rpsPresets = [150, 200, 300, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 10000, 50000, 100000];
  const trafficTypes = ['RADIUS', 'TACACS+', 'Syslog'];
  const authTypes = ['PAP', 'CHAP', 'MS-CHAPv2', 'EAP-MD5', 'EAP-TLS', 'PEAP', 'EAP-TTLS', 'EAP-FAST', 'MAB'];
  const rpsProfiles = ['Constant', 'Step', 'Ramp', 'Burst'];

  const handleStart = () => {
    setIsRunning(true);
    setIsPaused(false);
    // TODO: Call API to start test
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
    // TODO: Call API to pause/resume test
  };

  const handleStop = () => {
    setIsRunning(false);
    setIsPaused(false);
    // TODO: Call API to stop test
  };

  const handleSavePreset = () => {
    // TODO: Save current configuration as preset
    alert('Preset saved successfully!');
  };

  const handleLoadPreset = () => {
    // TODO: Load preset configuration
    alert('Preset loaded successfully!');
  };

  const handleExportCsv = () => {
    // TODO: Export metrics to CSV
    alert('CSV export started!');
  };

  return (
    <div className="scale-test-page">
      <div className="page-header">
        <h1>Scale Test (RPS Planner)</h1>
        <p>Drive controlled RPS at target(s) to validate scaling limits</p>
      </div>

      <div className="test-configuration">
        <div className="config-section">
          <h2>Target Configuration</h2>
          <div className="config-grid">
            <div className="config-item">
              <label>Target Type:</label>
              <select value={target.type} onChange={(e) => setTarget({...target, type: e.target.value})}>
                <option value="Asset Manager">Asset Manager</option>
                <option value="Cisco ISE">Cisco ISE</option>
              </select>
            </div>
            <div className="config-item">
              <label>Host/IP:</label>
              <input 
                type="text" 
                value={target.host} 
                onChange={(e) => setTarget({...target, host: e.target.value})}
                placeholder="192.168.1.100"
              />
            </div>
            <div className="config-item">
              <label>Port:</label>
              <input 
                type="number" 
                value={target.port} 
                onChange={(e) => setTarget({...target, port: e.target.value})}
              />
            </div>
            <div className="config-item">
              <label>Shared Secret:</label>
              <input 
                type="password" 
                value={target.secret} 
                onChange={(e) => setTarget({...target, secret: e.target.value})}
                placeholder="Enter shared secret"
              />
            </div>
          </div>
        </div>

        <div className="config-section">
          <h2>Traffic Configuration</h2>
          <div className="config-grid">
            <div className="config-item">
              <label>Traffic Type:</label>
              <select value={trafficConfig.type} onChange={(e) => setTrafficConfig({...trafficConfig, type: e.target.value})}>
                {trafficTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
            <div className="config-item">
              <label>Auth Type:</label>
              <select value={trafficConfig.authType} onChange={(e) => setTrafficConfig({...trafficConfig, authType: e.target.value})}>
                {authTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
            <div className="config-item">
              <label>RPS Profile:</label>
              <select value={trafficConfig.rpsProfile} onChange={(e) => setTrafficConfig({...trafficConfig, rpsProfile: e.target.value})}>
                {rpsProfiles.map(profile => (
                  <option key={profile} value={profile}>{profile}</option>
                ))}
              </select>
            </div>
            <div className="config-item">
              <label>RPS Value:</label>
              <select value={trafficConfig.rpsValue} onChange={(e) => setTrafficConfig({...trafficConfig, rpsValue: parseInt(e.target.value)})}>
                {rpsPresets.map(rps => (
                  <option key={rps} value={rps}>{rps.toLocaleString()}</option>
                ))}
              </select>
            </div>
            <div className="config-item">
              <label>Duration (mm:ss):</label>
              <input 
                type="text" 
                value={trafficConfig.duration} 
                onChange={(e) => setTrafficConfig({...trafficConfig, duration: e.target.value})}
                placeholder="05:00"
              />
            </div>
            <div className="config-item">
              <label>Clients/Sockets:</label>
              <input 
                type="number" 
                value={trafficConfig.clients} 
                onChange={(e) => setTrafficConfig({...trafficConfig, clients: parseInt(e.target.value)})}
                min="1"
                max="1000"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="live-kpis">
        <h2>Live KPIs</h2>
        <div className="kpi-tiles">
          <div className="kpi-tile">
            <div className="kpi-label">Current RPS</div>
            <div className="kpi-value">{liveKpis.currentRps.toLocaleString()}</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Target RPS</div>
            <div className="kpi-value">{liveKpis.targetRps.toLocaleString()}</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Delivered %</div>
            <div className="kpi-value">{liveKpis.deliveredPercent.toFixed(1)}%</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">TPS</div>
            <div className="kpi-value">{liveKpis.tps.toLocaleString()}</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Active Sockets</div>
            <div className="kpi-value">{liveKpis.activeSockets}</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Latency p50</div>
            <div className="kpi-value">{liveKpis.latencyP50}ms</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Latency p95</div>
            <div className="kpi-value">{liveKpis.latencyP95}ms</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Latency p99</div>
            <div className="kpi-value">{liveKpis.latencyP99}ms</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Success Rate</div>
            <div className="kpi-value">{liveKpis.successRate.toFixed(1)}%</div>
          </div>
          <div className="kpi-tile">
            <div className="kpi-label">Error Rate</div>
            <div className="kpi-value">{liveKpis.errorRate.toFixed(1)}%</div>
          </div>
        </div>
      </div>

      <div className="charts-section">
        <h2>Real-time Charts</h2>
        <div className="chart-placeholder">
          <p>RPS Delivered vs Target (Time-series chart)</p>
        </div>
        <div className="chart-placeholder">
          <p>Latency p50/p95/p99 (Time-series chart)</p>
        </div>
        <div className="chart-placeholder">
          <p>Error Classes Stacked (Timeouts/Auth-reject/Parse)</p>
        </div>
      </div>

      <div className="control-actions">
        <div className="action-buttons">
          {!isRunning ? (
            <button className="btn-primary" onClick={handleStart}>Start Test</button>
          ) : (
            <>
              <button className="btn-secondary" onClick={handlePause}>
                {isPaused ? 'Resume' : 'Pause'}
              </button>
              <button className="btn-danger" onClick={handleStop}>Stop Test</button>
            </>
          )}
          <button className="btn-secondary" onClick={handleSavePreset}>Save Preset</button>
          <button className="btn-secondary" onClick={handleLoadPreset}>Load Preset</button>
          <button className="btn-secondary" onClick={handleExportCsv}>Export CSV</button>
        </div>
      </div>

      <style jsx>{`
        .scale-test-page {
          padding: 20px;
          max-width: 1200px;
          margin: 0 auto;
        }

        .page-header {
          margin-bottom: 30px;
        }

        .page-header h1 {
          color: #333;
          margin-bottom: 10px;
        }

        .config-section {
          background: #f8f9fa;
          padding: 20px;
          border-radius: 8px;
          margin-bottom: 20px;
        }

        .config-section h2 {
          margin-bottom: 15px;
          color: #555;
        }

        .config-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 15px;
        }

        .config-item {
          display: flex;
          flex-direction: column;
        }

        .config-item label {
          margin-bottom: 5px;
          font-weight: 500;
          color: #666;
        }

        .config-item input,
        .config-item select {
          padding: 8px 12px;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 14px;
        }

        .live-kpis {
          margin: 30px 0;
        }

        .kpi-tiles {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 15px;
          margin-top: 15px;
        }

        .kpi-tile {
          background: white;
          padding: 15px;
          border-radius: 8px;
          text-align: center;
          border: 1px solid #e0e0e0;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .kpi-label {
          font-size: 12px;
          color: #666;
          margin-bottom: 8px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .kpi-value {
          font-size: 24px;
          font-weight: bold;
          color: #333;
        }

        .charts-section {
          margin: 30px 0;
        }

        .chart-placeholder {
          background: #f0f0f0;
          height: 200px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 15px;
          color: #666;
          border: 2px dashed #ccc;
        }

        .control-actions {
          margin-top: 30px;
          text-align: center;
        }

        .action-buttons {
          display: flex;
          gap: 15px;
          justify-content: center;
          flex-wrap: wrap;
        }

        .btn-primary,
        .btn-secondary,
        .btn-danger {
          padding: 10px 20px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          transition: background-color 0.2s;
        }

        .btn-primary {
          background-color: #007bff;
          color: white;
        }

        .btn-primary:hover {
          background-color: #0056b3;
        }

        .btn-secondary {
          background-color: #6c757d;
          color: white;
        }

        .btn-secondary:hover {
          background-color: #545b62;
        }

        .btn-danger {
          background-color: #dc3545;
          color: white;
        }

        .btn-danger:hover {
          background-color: #c82333;
        }
      `}</style>
    </div>
  );
};

export default ScaleTest;