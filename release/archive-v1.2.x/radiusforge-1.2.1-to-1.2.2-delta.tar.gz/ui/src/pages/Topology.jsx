import { useState, useEffect, useRef } from 'react';

const Topology = () => {
  const canvasRef = useRef(null);
  const [nodes, setNodes] = useState([]);
  const [connections, setConnections] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const [viewMode, setViewMode] = useState('live');
  const [filters, setFilters] = useState({
    showHealthy: true,
    showWarning: true,
    showCritical: true,
    showTrafficFlows: true,
    nodeType: 'all'
  });

  const [stats, setStats] = useState({
    totalNodes: 0,
    healthyNodes: 0,
    warningNodes: 0,
    criticalNodes: 0,
    totalRps: 0,
    avgLatency: 0
  });

  // Initialize topology with mock data
  useEffect(() => {
    initializeTopology();
    
    // Start live updates simulation
    const interval = setInterval(() => {
      if (viewMode === 'live') {
        updateLiveMetrics();
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [viewMode]);

  const initializeTopology = () => {
    const mockNodes = [
      // RadiusForge instances
      {
        id: 'rf-main',
        type: 'radiusforge',
        name: 'RadiusForge Main',
        x: 100,
        y: 200,
        status: 'healthy',
        rps: 5000,
        latency: 45,
        connections: 3,
        details: {
          version: '1.2.0',
          uptime: '2d 14h 32m',
          cpu: 25,
          memory: 45,
          activeTests: 2
        }
      },
      {
        id: 'rf-backup',
        type: 'radiusforge',
        name: 'RadiusForge Backup',
        x: 100,
        y: 350,
        status: 'warning',
        rps: 1200,
        latency: 78,
        connections: 1,
        details: {
          version: '1.1.5',
          uptime: '5d 8h 12m',
          cpu: 15,
          memory: 30,
          activeTests: 1
        }
      },
      // Asset Manager instances
      {
        id: 'am-primary',
        type: 'asset-manager',
        name: 'Asset Manager Primary',
        x: 400,
        y: 150,
        status: 'healthy',
        rps: 4500,
        latency: 42,
        connections: 2,
        details: {
          version: '3.2.1',
          uptime: '12d 6h 45m',
          cpu: 65,
          memory: 78,
          sessionsActive: 15420
        }
      },
      {
        id: 'am-secondary',
        type: 'asset-manager',
        name: 'Asset Manager Secondary',
        x: 400,
        y: 300,
        status: 'healthy',
        rps: 2100,
        latency: 38,
        connections: 1,
        details: {
          version: '3.2.1',
          uptime: '8d 2h 15m',
          cpu: 45,
          memory: 56,
          sessionsActive: 8920
        }
      },
      // Cisco ISE
      {
        id: 'ise-primary',
        type: 'cisco-ise',
        name: 'Cisco ISE Primary',
        x: 700,
        y: 200,
        status: 'critical',
        rps: 800,
        latency: 250,
        connections: 1,
        details: {
          version: '3.1.0.518',
          uptime: '25d 12h 8m',
          cpu: 85,
          memory: 92,
          activeSessions: 5240
        }
      },
      // NADs
      {
        id: 'switch-core',
        type: 'nad',
        name: 'Core Switch',
        x: 250,
        y: 50,
        status: 'healthy',
        rps: 1500,
        latency: 15,
        connections: 2,
        details: {
          model: 'Catalyst 9300',
          firmware: '16.12.08',
          ports: 48,
          uptime: '45d 3h 22m'
        }
      },
      {
        id: 'wlc-main',
        type: 'nad',
        name: 'Wireless Controller',
        x: 550,
        y: 50,
        status: 'warning',
        rps: 2200,
        latency: 65,
        connections: 2,
        details: {
          model: 'WLC 5520',
          firmware: '8.10.162.0',
          aps: 120,
          clients: 850
        }
      },
      // Database
      {
        id: 'db-primary',
        type: 'database',
        name: 'Primary Database',
        x: 550,
        y: 400,
        status: 'healthy',
        rps: 0,
        latency: 8,
        connections: 3,
        details: {
          type: 'PostgreSQL 13',
          size: '145 GB',
          connections: 45,
          uptime: '30d 8h 15m'
        }
      }
    ];

    const mockConnections = [
      { from: 'rf-main', to: 'am-primary', traffic: 4500, latency: 42, status: 'healthy' },
      { from: 'rf-main', to: 'am-secondary', traffic: 500, latency: 38, status: 'healthy' },
      { from: 'rf-backup', to: 'ise-primary', traffic: 800, latency: 250, status: 'critical' },
      { from: 'switch-core', to: 'am-primary', traffic: 1500, latency: 35, status: 'healthy' },
      { from: 'wlc-main', to: 'am-primary', traffic: 2200, latency: 48, status: 'warning' },
      { from: 'wlc-main', to: 'ise-primary', traffic: 0, latency: 0, status: 'disconnected' },
      { from: 'am-primary', to: 'db-primary', traffic: 0, latency: 8, status: 'healthy' },
      { from: 'am-secondary', to: 'db-primary', traffic: 0, latency: 10, status: 'healthy' },
      { from: 'ise-primary', to: 'db-primary', traffic: 0, latency: 12, status: 'healthy' }
    ];

    setNodes(mockNodes);
    setConnections(mockConnections);
    updateStats(mockNodes);
  };

  const updateLiveMetrics = () => {
    setNodes(prevNodes => 
      prevNodes.map(node => ({
        ...node,
        rps: node.rps + (Math.random() - 0.5) * 100,
        latency: Math.max(1, node.latency + (Math.random() - 0.5) * 10),
        details: {
          ...node.details,
          cpu: Math.max(0, Math.min(100, node.details.cpu + (Math.random() - 0.5) * 5)),
          memory: Math.max(0, Math.min(100, node.details.memory + (Math.random() - 0.5) * 3))
        }
      }))
    );
  };

  const updateStats = (nodeList) => {
    const healthy = nodeList.filter(n => n.status === 'healthy').length;
    const warning = nodeList.filter(n => n.status === 'warning').length;
    const critical = nodeList.filter(n => n.status === 'critical').length;
    const totalRps = nodeList.reduce((sum, n) => sum + (n.rps || 0), 0);
    const avgLatency = nodeList.reduce((sum, n) => sum + (n.latency || 0), 0) / nodeList.length;

    setStats({
      totalNodes: nodeList.length,
      healthyNodes: healthy,
      warningNodes: warning,
      criticalNodes: critical,
      totalRps: Math.round(totalRps),
      avgLatency: Math.round(avgLatency)
    });
  };

  const handleNodeClick = (node) => {
    setSelectedNode(node);
  };

  const handleFilterChange = (filterKey, value) => {
    setFilters(prev => ({
      ...prev,
      [filterKey]: value
    }));
  };

  const getNodeColor = (node) => {
    switch (node.status) {
      case 'healthy': return '#28a745';
      case 'warning': return '#ffc107';
      case 'critical': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const getNodeIcon = (type) => {
    switch (type) {
      case 'radiusforge': return '🔥';
      case 'asset-manager': return '🛡️';
      case 'cisco-ise': return '🌐';
      case 'nad': return '📡';
      case 'database': return '💾';
      default: return '⚡';
    }
  };

  const filteredNodes = nodes.filter(node => {
    if (!filters.showHealthy && node.status === 'healthy') return false;
    if (!filters.showWarning && node.status === 'warning') return false;
    if (!filters.showCritical && node.status === 'critical') return false;
    if (filters.nodeType !== 'all' && node.type !== filters.nodeType) return false;
    return true;
  });

  return (
    <div className="topology-page">
      <div className="page-header">
        <h1>Network Topology</h1>
        <p>Interactive visualization of test infrastructure and real-time health metrics</p>
      </div>

      <div className="topology-controls">
        <div className="view-controls">
          <label>View Mode:</label>
          <select value={viewMode} onChange={(e) => setViewMode(e.target.value)}>
            <option value="live">Live Metrics</option>
            <option value="static">Static View</option>
            <option value="historical">Historical</option>
          </select>
        </div>

        <div className="filter-controls">
          <label>Show:</label>
          <label className="checkbox-label">
            <input 
              type="checkbox"
              checked={filters.showHealthy}
              onChange={(e) => handleFilterChange('showHealthy', e.target.checked)}
            />
            <span className="status-indicator healthy"></span>
            <span>Healthy</span>
          </label>
          <label className="checkbox-label">
            <input 
              type="checkbox"
              checked={filters.showWarning}
              onChange={(e) => handleFilterChange('showWarning', e.target.checked)}
            />
            <span className="status-indicator warning"></span>
            <span>Warning</span>
          </label>
          <label className="checkbox-label">
            <input 
              type="checkbox"
              checked={filters.showCritical}
              onChange={(e) => handleFilterChange('showCritical', e.target.checked)}
            />
            <span className="status-indicator critical"></span>
            <span>Critical</span>
          </label>
        </div>

        <div className="node-type-filter">
          <label>Node Type:</label>
          <select value={filters.nodeType} onChange={(e) => handleFilterChange('nodeType', e.target.value)}>
            <option value="all">All Types</option>
            <option value="radiusforge">RadiusForge</option>
            <option value="asset-manager">Asset Manager</option>
            <option value="cisco-ise">Cisco ISE</option>
            <option value="nad">NAD</option>
            <option value="database">Database</option>
          </select>
        </div>
      </div>

      <div className="topology-stats">
        <div className="stat-card">
          <div className="stat-value">{stats.totalNodes}</div>
          <div className="stat-label">Total Nodes</div>
        </div>
        <div className="stat-card healthy">
          <div className="stat-value">{stats.healthyNodes}</div>
          <div className="stat-label">Healthy</div>
        </div>
        <div className="stat-card warning">
          <div className="stat-value">{stats.warningNodes}</div>
          <div className="stat-label">Warning</div>
        </div>
        <div className="stat-card critical">
          <div className="stat-value">{stats.criticalNodes}</div>
          <div className="stat-label">Critical</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.totalRps.toLocaleString()}</div>
          <div className="stat-label">Total RPS</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.avgLatency}ms</div>
          <div className="stat-label">Avg Latency</div>
        </div>
      </div>

      <div className="topology-container">
        <div className="topology-canvas">
          <svg width="800" height="500" className="topology-svg">
            {/* Connection lines */}
            {filters.showTrafficFlows && connections.map((conn, index) => {
              const fromNode = nodes.find(n => n.id === conn.from);
              const toNode = nodes.find(n => n.id === conn.to);
              if (!fromNode || !toNode) return null;

              return (
                <g key={index}>
                  <line
                    x1={fromNode.x + 30}
                    y1={fromNode.y + 30}
                    x2={toNode.x + 30}
                    y2={toNode.y + 30}
                    stroke={conn.status === 'healthy' ? '#28a745' : conn.status === 'warning' ? '#ffc107' : '#dc3545'}
                    strokeWidth={Math.max(1, conn.traffic / 1000)}
                    strokeDasharray={conn.status === 'disconnected' ? '5,5' : 'none'}
                  />
                  {/* Traffic indicator */}
                  {conn.traffic > 0 && (
                    <text
                      x={(fromNode.x + toNode.x) / 2 + 30}
                      y={(fromNode.y + toNode.y) / 2 + 25}
                      fill="#666"
                      fontSize="10"
                      textAnchor="middle"
                    >
                      {conn.traffic > 1000 ? `${(conn.traffic/1000).toFixed(1)}k` : conn.traffic}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Nodes */}
            {filteredNodes.map(node => (
              <g 
                key={node.id} 
                className="topology-node"
                onClick={() => handleNodeClick(node)}
              >
                <circle
                  cx={node.x + 30}
                  cy={node.y + 30}
                  r="25"
                  fill={getNodeColor(node)}
                  stroke="#fff"
                  strokeWidth="3"
                  style={{ cursor: 'pointer' }}
                />
                <text
                  x={node.x + 30}
                  y={node.y + 35}
                  fill="white"
                  fontSize="16"
                  textAnchor="middle"
                >
                  {getNodeIcon(node.type)}
                </text>
                <text
                  x={node.x + 30}
                  y={node.y + 70}
                  fill="#333"
                  fontSize="11"
                  textAnchor="middle"
                  fontWeight="500"
                >
                  {node.name}
                </text>
                {/* Live metrics */}
                {viewMode === 'live' && (
                  <text
                    x={node.x + 30}
                    y={node.y + 85}
                    fill="#666"
                    fontSize="9"
                    textAnchor="middle"
                  >
                    {node.rps > 0 ? `${Math.round(node.rps)} RPS` : ''} {node.latency}ms
                  </text>
                )}
              </g>
            ))}
          </svg>
        </div>

        {selectedNode && (
          <div className="node-details">
            <div className="details-header">
              <h3>{selectedNode.name}</h3>
              <button onClick={() => setSelectedNode(null)}>×</button>
            </div>
            <div className="details-content">
              <div className="detail-row">
                <span className="detail-label">Type:</span>
                <span className="detail-value">{selectedNode.type}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Status:</span>
                <span className={`detail-value status-${selectedNode.status}`}>
                  {selectedNode.status.toUpperCase()}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-label">RPS:</span>
                <span className="detail-value">{Math.round(selectedNode.rps || 0)}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Latency:</span>
                <span className="detail-value">{Math.round(selectedNode.latency || 0)}ms</span>
              </div>
              
              <div className="details-section">
                <h4>Additional Details</h4>
                {Object.entries(selectedNode.details || {}).map(([key, value]) => (
                  <div key={key} className="detail-row">
                    <span className="detail-label">
                      {key.charAt(0).toUpperCase() + key.slice(1)}:
                    </span>
                    <span className="detail-value">
                      {typeof value === 'number' && (key === 'cpu' || key === 'memory') 
                        ? `${value}%` 
                        : value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        .topology-page {
          padding: 20px;
          max-width: 1400px;
          margin: 0 auto;
        }

        .page-header {
          margin-bottom: 30px;
        }

        .page-header h1 {
          color: #333;
          margin-bottom: 10px;
        }

        .topology-controls {
          display: flex;
          gap: 30px;
          background: #f8f9fa;
          padding: 15px 20px;
          border-radius: 8px;
          margin-bottom: 20px;
          flex-wrap: wrap;
          align-items: center;
        }

        .view-controls,
        .node-type-filter {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .view-controls label,
        .node-type-filter label {
          font-weight: 500;
          color: #555;
        }

        .view-controls select,
        .node-type-filter select {
          padding: 5px 10px;
          border: 1px solid #ddd;
          border-radius: 4px;
        }

        .filter-controls {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .filter-controls > label {
          font-weight: 500;
          color: #555;
        }

        .checkbox-label {
          display: flex;
          align-items: center;
          gap: 5px;
          cursor: pointer;
          font-size: 14px;
        }

        .status-indicator {
          width: 12px;
          height: 12px;
          border-radius: 50%;
        }

        .status-indicator.healthy {
          background-color: #28a745;
        }

        .status-indicator.warning {
          background-color: #ffc107;
        }

        .status-indicator.critical {
          background-color: #dc3545;
        }

        .topology-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          gap: 15px;
          margin-bottom: 20px;
        }

        .stat-card {
          background: white;
          padding: 15px;
          border-radius: 8px;
          text-align: center;
          border: 1px solid #e0e0e0;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-card.healthy {
          border-left: 4px solid #28a745;
        }

        .stat-card.warning {
          border-left: 4px solid #ffc107;
        }

        .stat-card.critical {
          border-left: 4px solid #dc3545;
        }

        .stat-value {
          font-size: 24px;
          font-weight: bold;
          color: #333;
          margin-bottom: 5px;
        }

        .stat-label {
          font-size: 12px;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .topology-container {
          display: flex;
          gap: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          overflow: hidden;
        }

        .topology-canvas {
          flex: 1;
          padding: 20px;
        }

        .topology-svg {
          border: 1px solid #e0e0e0;
          border-radius: 4px;
          background: #fafafa;
        }

        .topology-node {
          transition: all 0.2s;
        }

        .topology-node:hover circle {
          stroke-width: 4;
          filter: brightness(1.1);
        }

        .node-details {
          width: 300px;
          background: #f8f9fa;
          border-left: 1px solid #e0e0e0;
          display: flex;
          flex-direction: column;
        }

        .details-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 15px 20px;
          background: #fff;
          border-bottom: 1px solid #e0e0e0;
        }

        .details-header h3 {
          margin: 0;
          color: #333;
        }

        .details-header button {
          background: none;
          border: none;
          font-size: 20px;
          cursor: pointer;
          color: #666;
          padding: 0;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .details-content {
          padding: 20px;
          flex: 1;
        }

        .detail-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 10px;
          padding-bottom: 8px;
          border-bottom: 1px solid #eee;
        }

        .detail-label {
          font-weight: 500;
          color: #555;
        }

        .detail-value {
          color: #333;
        }

        .detail-value.status-healthy {
          color: #28a745;
          font-weight: 600;
        }

        .detail-value.status-warning {
          color: #ffc107;
          font-weight: 600;
        }

        .detail-value.status-critical {
          color: #dc3545;
          font-weight: 600;
        }

        .details-section {
          margin-top: 20px;
          padding-top: 15px;
          border-top: 2px solid #ddd;
        }

        .details-section h4 {
          margin: 0 0 15px 0;
          color: #555;
          font-size: 14px;
        }
      `}</style>
    </div>
  );
};

export default Topology;