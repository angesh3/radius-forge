import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import ScaleTest from './pages/ScaleTest';
import PerformanceTest from './pages/PerformanceTest';
import ThreatGenerator from './pages/ThreatGenerator';
import Report from './pages/Report';
import Topology from './pages/Topology';
import History from './pages/History';
import Help from './pages/Help';
import './App.css';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<ScaleTest />} />
          <Route path="/scale-test" element={<ScaleTest />} />
          <Route path="/performance-test" element={<PerformanceTest />} />
          <Route path="/threat-generator" element={<ThreatGenerator />} />
          <Route path="/report" element={<Report />} />
          <Route path="/topology" element={<Topology />} />
          <Route path="/history" element={<History />} />
          <Route path="/help" element={<Help />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
